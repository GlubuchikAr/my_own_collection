# Ansible Collection - my_own_namespace.yandex_cloud_elk

## Description

Easy creation of a file with content

## Requirements

- Ansible >= 2.18 (It might work on previous versions, but we cannot guarantee it)
- Debian and python on deployer machine.
- Python >=3.10

## Role Variables

## License

This project is licensed under MIT License.

